import goto_plus
from goto_plus.goto import goto, gotoconfig